{

    int a;
    int b;
    int z;
    z = a + b++;
}