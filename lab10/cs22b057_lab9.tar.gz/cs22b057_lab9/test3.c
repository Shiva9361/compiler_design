{

    int a;
    int b;
    {
        int a;
        {
            float b;
            int a, c[98.9], d[1][100];
            {
                int c;
            }
        }
    }
}