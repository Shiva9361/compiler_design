{

    int a;
    int x, y;
    float c = a + x + y + a;
    x = a + x;
    {
        int a = 0.1 + x;
        int b;
    }
    {

        char m;
        int n[10];
    }
}