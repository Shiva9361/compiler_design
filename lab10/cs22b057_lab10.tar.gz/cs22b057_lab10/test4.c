int a = 10;
while (a < 10)
{
    int x, y;
    float c = a + x + y + a;
    x = a + x;
    if (c == 10)
    {
        int a = 0.1 + x;
        int b;
    }
    {

        char m;
        int n[10][2];
    }
    a++;
}