
int a = 10;
int b = 4;
if (a < 10 && b < 10 && (!a > b))
{
    a = a + b * 1.3;
}
