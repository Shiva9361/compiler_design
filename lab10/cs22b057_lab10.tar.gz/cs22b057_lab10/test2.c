{

    int a;
    char a;
    {
        int c;
        int c;
        z = a + c;
    }
}