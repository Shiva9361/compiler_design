{

    int a;
    float b;
    int c;
    int z;
    z = a + b * c;
    z = a % 3.4;
}